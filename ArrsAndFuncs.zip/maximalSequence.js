function solve(arg) {
var x = arg.map(Number),
    i,
    br = 0,
    count = 0;
for (i=0; i<x.length; i+=1) {
        if(x[i]==x[i+1]) {
            count +=1;            
        } else {
            count = 0;
        }
        if (count > br) {
            br = count;
        } 
}
    
console.log(br+1);
}