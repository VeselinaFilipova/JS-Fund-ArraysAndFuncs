function solve(args) {
     var arr = args[1].split(' ').map(Number),
     size = +args[0],
     num = +args[2],
     br=0;

     function test(array, number) {
for (var i=0; i<array.length; i+=1) {
    if(array[i]===number) {
        br+=1;
    }
} 
console.log(br);
}
test(arr, num);
}