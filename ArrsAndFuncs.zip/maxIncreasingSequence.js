function solve(arg) {
var x = arg.map(Number),
    n = x.shift(),
    i,
    br = 0,
    count = 0;
for (i=0; i<n-1; i+=1) {
        if((x[i]+1)===x[i+1]) {
            count +=1;   
             if (count > br) {
            br = count;
        }    
        } else {
            count = 0;
        }
    }

console.log(br+1);
}