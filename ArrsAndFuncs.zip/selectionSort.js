function solve(args) {
var xarr = args.map(Number),
n = xarr.shift(),
arr = [],
i,
b;
while (xarr.length > 0) {
var b = Math.min(...xarr);
    for (i = 0; i<xarr.length; i+=1) {
        if (xarr[i]===b) {
            var c = xarr.splice(i,1); 
            arr.push(c[0]);
            c[0]=0;
            } 
        } 
} console.log(arr.join("\n")); 
}