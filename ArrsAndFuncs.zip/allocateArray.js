function solve(arg) {
var n = +arg,
i;
if (n>=1 && n<=20) {
    for (i=0; i<n; i+=1) {
        console.log(i*5);
    }
} else {return false;}
}