function solve(args) {
     var arr = args[1].split(' ').map(Number),
     size = +args[0],
     arrnew = [],
     temp,
     maxim;

     function getMax(ar) {
         return Math.max(...ar);
     }

     function test(array) {
while(array.length>0) {
    maxim = getMax(array);
    var index = array.indexOf(maxim);
    temp = array.splice(index, 1);
    arrnew.push(temp[0]);
    }
    console.log(arrnew.join(' '));
    console.log(arrnew.reverse().join(' '));
} 
test(arr);
}
solve(['6', '3 4 1 5 2 6']);