function solve(args) {
     var arr = args[0].split(' '),
     size = +arr.shift(),
     num = +arr.pop(),
     br=0;
console.log(size);
console.log(arr);
console.log(num);
for (var i=0; i<size; i+=1) {
    if(+arr[i]===num) {
        br+=1;
    }
} console.log(br);
}