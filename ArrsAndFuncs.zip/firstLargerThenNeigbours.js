function solve(args) {
     var arr = args[1].split(' ').map(Number),
     size = +args[0],
     first;

     function test(array, len) {
for (var i=1; i<len-1; i+=1) {
    if(array[i]>array[i-1] && array[i]>array[i+1]) {
        return array.indexOf(array[i]);
    }
} 

}
first = test(arr, size);
console.log(first);
}