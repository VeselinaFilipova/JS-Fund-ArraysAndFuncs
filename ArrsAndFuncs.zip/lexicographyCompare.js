function solve(arg) {
var str1 = arg[0],
    str2 = arg[1];
if(str1.length == str2.length) {console.log("=");}
if (str1.length > str2.length) {console.log(">");}
if (str1.length < str2.length) {console.log("<");}
}