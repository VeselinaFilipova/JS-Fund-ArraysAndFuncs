function solve(args) {
     var arr = args[1].split(' ').map(Number),
     size = +args[0],
     br=0;

     function test(array, len) {
for (var i=1; i<len-1; i+=1) {
    if(array[i]>array[i-1] && array[i]>array[i+1]) {
        br+=1;
    }
} 
console.log(br);
}
test(arr, size);
}