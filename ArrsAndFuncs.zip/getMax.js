function GetMax(args) {
     var arr = args[0].split(' '),
     x = +arr[0],
    y = +arr[1],
    z = +arr[2];
console.log(Math.max(x, y, z));
}